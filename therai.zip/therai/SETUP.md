# Putting THERAI online (free, about 10 minutes)

## What's in this folder
- `index.html` — your THERAI website
- `api/chat.js` — keeps your AI key secret and talks to the AI
- `vercel.json` and `package.json` — small settings files for Vercel

## Step 1: Get an API key
1. Go to https://console.anthropic.com and sign up.
2. Open **API Keys** and click **Create Key**.
3. Copy the key and keep it private. Never paste it into index.html.

## Step 2: Put the site on Vercel
1. Unzip this file.
2. Go to https://vercel.com and sign up (free).
3. Click **Add New → Project**, then upload the unzipped `therai` folder
   (or push it to GitHub and import it from there).

## Step 3: Add your key
1. During setup (or later in **Settings → Environment Variables**) add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: the key from Step 1
2. Click **Deploy**. If you added the key after deploying, click **Redeploy**.

You'll get a live link like `therai.vercel.app`. Open it and say hello to the therapist.

## Notes
- The microphone button works best in Chrome, Edge and Safari.
- Opening index.html straight from your computer shows the site, but the
  chat only answers once it's running on Vercel with your key added.
- Shared stories show on the page right away but are not saved yet, so they
  disappear when the page is refreshed. Saving them needs a small database.
